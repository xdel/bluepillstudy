/*++

Copyright (c) 2004 - 2007, Intel Corporation                                                         
All rights reserved. This program and the accompanying materials                          
are licensed and made available under the terms and conditions of the BSD License         
which accompanies this distribution.  The full text of the license may be found at        
http://opensource.org/licenses/bsd-license.php                                            
                                                                                          
THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,                     
WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.             

Module Name:

    SampleDrv.c

Abstract:

    Top level C file for SAMPLEDRV driver.  Contains initialization function.
    This driver layers on top of SerialIo.
    
    ALL CODE IN THE SERIALIO STACK MUST BE RE-ENTRANT AND CALLABLE FROM
    INTERRUPT CONTEXT.

Revision History

--*/

#include "SampleDrv.h"

//
// Misc. functions local to this module
//
STATIC
VOID
GetSampleDrvVariable (
  SAMPLEDRV_DEVICE  *SampleDrvDevice
  );

STATIC
EFI_STATUS
EFIAPI
ImageUnloadHandler (
  EFI_HANDLE ImageHandle
  );

//
// Globals
//
SAMPLEDRV_DEVICE  *gSampleDrvDevice;
static UINT32     mHid16550;
static UINT32     mHidStdPcComPort;

//
// implementation code
//
EFI_DRIVER_ENTRY_POINT (InitializeSampleDrvDriver)

EFI_STATUS
EFIAPI
InitializeSampleDrvDriver (
  IN EFI_HANDLE             ImageHandle,
  IN EFI_SYSTEM_TABLE       *SystemTable
  )
/*++

Routine Description:
  Driver entry point.  Reads SampleDrv variable to determine what device and settings
  to use as the debug port.  Binds exclusively to SerialIo. Reverts to defaults \
  if no variable is found.  
  
  Creates SAMPLEDRV and devicepath protocols on new handle.

Arguments:
  ImageHandle,
  SystemTable

Returns:

  EFI_UNSUPPORTED
  EFI_OUT_OF_RESOURCES

--*/
{
  EFI_LOADED_IMAGE_PROTOCOL *LoadedImageInterface;

  mHid16550         = EFI_ACPI_16550UART_HID;
  mHidStdPcComPort  = EFI_ACPI_PC_COMPORT_HID;
  //EFI_CLASS_EDIT EFI DRIVER TRAINING
  //EFI_BREAKPOINT();
  //
  // Check to be sure we have an EFI 1.1 core
  //
  if (SystemTable->Hdr.Revision < EFI_1_10_SYSTEM_TABLE_REVISION) {
    return EFI_UNSUPPORTED;
  }
  //
  //  Initialize EFI driver library
  //
  EfiInitializeDriverLib (ImageHandle, SystemTable);

  //
  // Allocate and Initialize dev structure
  //
  gSampleDrvDevice = EfiLibAllocateZeroPool (sizeof (SAMPLEDRV_DEVICE));
  if (gSampleDrvDevice == NULL) {
    return EFI_OUT_OF_RESOURCES;
  }
  //
  // Fill in static and default pieces of device structure first.
  //
  gSampleDrvDevice->Signature = SAMPLEDRV_DEVICE_SIGNATURE;

  gSampleDrvDevice->DriverBindingInterface.Supported = SampleDrvSupported;
  gSampleDrvDevice->DriverBindingInterface.Start = SampleDrvStart;
  gSampleDrvDevice->DriverBindingInterface.Stop = SampleDrvStop;
  gSampleDrvDevice->DriverBindingInterface.Version = SAMPLEDRV_DRIVER_VERSION;
  gSampleDrvDevice->DriverBindingInterface.ImageHandle = ImageHandle;
  gSampleDrvDevice->DriverBindingInterface.DriverBindingHandle = ImageHandle;

  gSampleDrvDevice->ComponentNameInterface.GetDriverName = SampleDrvComponentNameGetDriverName;
  gSampleDrvDevice->ComponentNameInterface.GetControllerName = SampleDrvComponentNameGetControllerName;
  gSampleDrvDevice->ComponentNameInterface.SupportedLanguages = LANGUAGE_CODE_ENGLISH;

  gSampleDrvDevice->SampleDrvInterface.Reset = SampleDrvReset;
  gSampleDrvDevice->SampleDrvInterface.Read = SampleDrvRead;
  gSampleDrvDevice->SampleDrvInterface.Write = SampleDrvWrite;
  gSampleDrvDevice->SampleDrvInterface.Poll = SampleDrvPoll;

  gSampleDrvDevice->BaudRate = SAMPLEDRV_UART_DEFAULT_BAUDRATE;
  gSampleDrvDevice->ReceiveFifoDepth = SAMPLEDRV_UART_DEFAULT_FIFO_DEPTH;
  gSampleDrvDevice->Timeout = SAMPLEDRV_UART_DEFAULT_TIMEOUT;
  gSampleDrvDevice->Parity = SAMPLEDRV_UART_DEFAULT_PARITY;
  gSampleDrvDevice->DataBits = SAMPLEDRV_UART_DEFAULT_DATA_BITS;
  gSampleDrvDevice->StopBits = SAMPLEDRV_UART_DEFAULT_STOP_BITS;

  //
  //  Install unload handler...
  //
  gBS->OpenProtocol (
        ImageHandle,
        &gEfiLoadedImageProtocolGuid,
        &LoadedImageInterface,
        NULL,
        NULL,
        EFI_OPEN_PROTOCOL_GET_PROTOCOL
        );
  LoadedImageInterface->Unload = ImageUnloadHandler;

  //
  // Publish EFI 1.10 driver model protocols
  //
  return INSTALL_ALL_DRIVER_PROTOCOLS_OR_PROTOCOLS2 (
          ImageHandle,
          SystemTable,
          &gSampleDrvDevice->DriverBindingInterface,
          ImageHandle,
          &gSampleDrvDevice->ComponentNameInterface,
          NULL,
          NULL
          );
}
//
// SampleDrv driver binding member functions...
//
EFI_STATUS
EFIAPI
SampleDrvSupported (
  IN EFI_DRIVER_BINDING_PROTOCOL    *This,
  IN EFI_HANDLE                     ControllerHandle,
  IN EFI_DEVICE_PATH_PROTOCOL       *RemainingDevicePath
  )
/*++

Routine Description:
  Checks to see that there's not already a SampleDrv interface somewhere.  If so,
  fail.
  
  If there's a SAMPLEDRV variable, the device path must match exactly.  If there's
  no SAMPLEDRV variable, then device path is not checked and does not matter.
  
  Checks to see that there's a serial io interface on the controller handle
  that can be bound BY_DRIVER | EXCLUSIVE.
  
  If all these tests succeed, then we return EFI_SUCCESS, else, EFI_UNSUPPORTED
  or other error returned by OpenProtocol.

Arguments:
  This
  ControllerHandle
  RemainingDevicePath
  
Returns:
  EFI_UNSUPPORTED
  EFI_OUT_OF_RESOURCES
  EFI_SUCCESS
  
--*/
{
  EFI_STATUS                Status;
  EFI_DEVICE_PATH_PROTOCOL  *Dp1;
  EFI_DEVICE_PATH_PROTOCOL  *Dp2;
  EFI_SERIAL_IO_PROTOCOL    *SerialIo;
  EFI_SAMPLEDRV_PROTOCOL    *SampleDrvInterface;
  EFI_HANDLE                TempHandle;

  //
  // Check to see that there's not a SAMPLEDRV protocol already published
  //
  if (gBS->LocateProtocol (&gEfiSampleDrvProtocolGuid, NULL, (VOID **) &SampleDrvInterface) != EFI_NOT_FOUND) {
    return EFI_UNSUPPORTED;
  }
  //
  // Read SampleDrv variable to determine debug port selection and parameters
  //
  GetSampleDrvVariable (gSampleDrvDevice);

  if (gSampleDrvDevice->SampleDrvVariable != NULL) {
    //
    // There's a SAMPLEDRV variable, so do LocateDevicePath and check to see if
    // the closest matching handle matches the controller handle, and if it does,
    // check to see that the remaining device path has the SampleDrv GUIDed messaging
    // device path only.  Otherwise, it's a mismatch and EFI_UNSUPPORTED is returned.
    //
    Dp1 = EfiDuplicateDevicePath ((EFI_DEVICE_PATH_PROTOCOL *) gSampleDrvDevice->SampleDrvVariable);
    if (Dp1 == NULL) {
      return EFI_OUT_OF_RESOURCES;
    }

    Dp2 = Dp1;

    Status = gBS->LocateDevicePath (
                    &gEfiDebugSerialIoProtocolGuid,
                    &Dp2,
                    &TempHandle
                    );

    if (Status == EFI_SUCCESS && TempHandle != ControllerHandle) {
      Status = EFI_UNSUPPORTED;
    }

    if (Status == EFI_SUCCESS && (Dp2->Type != 3 || Dp2->SubType != 10 || *((UINT16 *) Dp2->Length) != 20)) {
      Status = EFI_UNSUPPORTED;
    }

    if (Status == EFI_SUCCESS && EfiCompareMem (&gEfiSampleDrvDevicePathGuid, Dp2 + 1, sizeof (EFI_GUID))) {
      Status = EFI_UNSUPPORTED;
    }

    gBS->FreePool (Dp1);
    if (EFI_ERROR (Status)) {
      return Status;
    }
  }

  Status = gBS->OpenProtocol (
                  ControllerHandle,
                  &gEfiDebugSerialIoProtocolGuid,
                  &SerialIo,
                  This->DriverBindingHandle,
                  ControllerHandle,
                  EFI_OPEN_PROTOCOL_BY_DRIVER | EFI_OPEN_PROTOCOL_EXCLUSIVE
                  );
  if (EFI_ERROR (Status)) {
    return Status;
  }

  gBS->CloseProtocol (
        ControllerHandle,
        &gEfiDebugSerialIoProtocolGuid,
        This->DriverBindingHandle,
        ControllerHandle
        );

  return EFI_SUCCESS;
}

EFI_STATUS
EFIAPI
SampleDrvStart (
  IN EFI_DRIVER_BINDING_PROTOCOL    *This,
  IN EFI_HANDLE                     ControllerHandle,
  IN EFI_DEVICE_PATH_PROTOCOL       *RemainingDevicePath
  )
/*++

Routine Description:
  Binds exclusively to serial io on the controller handle.  Produces SampleDrv
  protocol and DevicePath on new handle.

Arguments:
  This
  ControllerHandle
  RemainingDevicePath
  
Returns:
  EFI_OUT_OF_RESOURCES
  EFI_SUCCESS
--*/
{
  EFI_STATUS                Status;
  SAMPLEDRV_DEVICE_PATH     SampleDrvDP;
  EFI_DEVICE_PATH_PROTOCOL  EndDP;
  EFI_DEVICE_PATH_PROTOCOL  *Dp1;

  Status = gBS->OpenProtocol (
                  ControllerHandle,
                  &gEfiDebugSerialIoProtocolGuid,
                  &gSampleDrvDevice->SerialIoBinding,
                  This->DriverBindingHandle,
                  ControllerHandle,
                  EFI_OPEN_PROTOCOL_BY_DRIVER | EFI_OPEN_PROTOCOL_EXCLUSIVE
                  );
  if (EFI_ERROR (Status)) {
    return Status;
  }

  gSampleDrvDevice->SerialIoDeviceHandle = ControllerHandle;

  //
  // Initialize the Serial Io interface...
  //
  Status = gSampleDrvDevice->SerialIoBinding->SetAttributes (
                                                gSampleDrvDevice->SerialIoBinding,
                                                gSampleDrvDevice->BaudRate,
                                                gSampleDrvDevice->ReceiveFifoDepth,
                                                gSampleDrvDevice->Timeout,
                                                gSampleDrvDevice->Parity,
                                                gSampleDrvDevice->DataBits,
                                                gSampleDrvDevice->StopBits
                                                );
  if (EFI_ERROR (Status)) {
    gSampleDrvDevice->BaudRate          = 0;
    gSampleDrvDevice->Parity            = DefaultParity;
    gSampleDrvDevice->DataBits          = 0;
    gSampleDrvDevice->StopBits          = DefaultStopBits;
    gSampleDrvDevice->ReceiveFifoDepth  = 0;
    Status = gSampleDrvDevice->SerialIoBinding->SetAttributes (
                                                  gSampleDrvDevice->SerialIoBinding,
                                                  gSampleDrvDevice->BaudRate,
                                                  gSampleDrvDevice->ReceiveFifoDepth,
                                                  gSampleDrvDevice->Timeout,
                                                  gSampleDrvDevice->Parity,
                                                  gSampleDrvDevice->DataBits,
                                                  gSampleDrvDevice->StopBits
                                                  );
    if (EFI_ERROR (Status)) {
      gBS->CloseProtocol (
            ControllerHandle,
            &gEfiDebugSerialIoProtocolGuid,
            This->DriverBindingHandle,
            ControllerHandle
            );
      return Status;
    }
  }

  gSampleDrvDevice->SerialIoBinding->Reset (gSampleDrvDevice->SerialIoBinding);

  //
  // Create device path instance for SampleDrv
  //
  SampleDrvDP.Header.Type     = MESSAGING_DEVICE_PATH;
  SampleDrvDP.Header.SubType  = MSG_VENDOR_DP;
  SetDevicePathNodeLength (&(SampleDrvDP.Header), sizeof (SampleDrvDP));
  gBS->CopyMem (&SampleDrvDP.Guid, &gEfiSampleDrvDevicePathGuid, sizeof (EFI_GUID));

  Dp1 = EfiDevicePathFromHandle (ControllerHandle);
  if (Dp1 == NULL) {
    Dp1 = &EndDP;
    SetDevicePathEndNode (Dp1);
  }

  gSampleDrvDevice->SampleDrvDevicePath = EfiAppendDevicePathNode (Dp1, (EFI_DEVICE_PATH_PROTOCOL *) &SampleDrvDP);
  if (gSampleDrvDevice->SampleDrvDevicePath == NULL) {
    return EFI_OUT_OF_RESOURCES;
  }
  //
  // Publish SampleDrv and Device Path protocols
  //
  Status = gBS->InstallMultipleProtocolInterfaces (
                  &gSampleDrvDevice->SampleDrvDeviceHandle,
                  &gEfiDevicePathProtocolGuid,
                  gSampleDrvDevice->SampleDrvDevicePath,
                  &gEfiSampleDrvProtocolGuid,
                  &gSampleDrvDevice->SampleDrvInterface,
                  NULL
                  );

  if (EFI_ERROR (Status)) {
    gBS->CloseProtocol (
          ControllerHandle,
          &gEfiDebugSerialIoProtocolGuid,
          This->DriverBindingHandle,
          ControllerHandle
          );
    return Status;
  }
  //
  // Connect SAMPLEDRV child to serial io
  //
  Status = gBS->OpenProtocol (
                  ControllerHandle,
                  &gEfiDebugSerialIoProtocolGuid,
                  &gSampleDrvDevice->SerialIoBinding,
                  This->DriverBindingHandle,
                  gSampleDrvDevice->SampleDrvDeviceHandle,
                  EFI_OPEN_PROTOCOL_BY_CHILD_CONTROLLER
                  );

  if (EFI_ERROR (Status)) {
    DEBUG_CODE (
    {
      UINTN BufferSize = 48;
      SampleDrvWrite (
        &gSampleDrvDevice->SampleDrvInterface,
        0,
        &BufferSize,
        "SampleDrv driver failed to open child controller\r\n\n"
        );
    }
    )

    gBS->CloseProtocol (
          ControllerHandle,
          &gEfiDebugSerialIoProtocolGuid,
          This->DriverBindingHandle,
          ControllerHandle
          );
    return Status;
  }

  DEBUG_CODE (
  {
    UINTN BufferSize = 38;
    SampleDrvWrite (
      &gSampleDrvDevice->SampleDrvInterface,
      0,
      &BufferSize,
      "Hello World from the SampleDrv driver\r\n\n"
      );
  }
  )

  return EFI_SUCCESS;
}

EFI_STATUS
EFIAPI
SampleDrvStop (
  IN  EFI_DRIVER_BINDING_PROTOCOL    *This,
  IN  EFI_HANDLE                     ControllerHandle,
  IN  UINTN                          NumberOfChildren,
  IN  EFI_HANDLE                     *ChildHandleBuffer
  )
/*++

Routine Description:
  We're never intending to be stopped via the driver model so this just returns
  EFI_UNSUPPORTED

Arguments:
  Per EFI 1.10 driver model
  
Returns:
  EFI_UNSUPPORTED
  EFI_SUCCESS
  
--*/
{
  EFI_STATUS  Status;

  if (NumberOfChildren == 0) {
    //
    // Close the bus driver
    //
    gBS->CloseProtocol (
          ControllerHandle,
          &gEfiDebugSerialIoProtocolGuid,
          This->DriverBindingHandle,
          ControllerHandle
          );

    gSampleDrvDevice->SerialIoBinding = NULL;

    gBS->CloseProtocol (
          ControllerHandle,
          &gEfiDevicePathProtocolGuid,
          This->DriverBindingHandle,
          ControllerHandle
          );

    gBS->FreePool (gSampleDrvDevice->SampleDrvDevicePath);

    return EFI_SUCCESS;
  } else {
    //
    // Disconnect SerialIo child handle
    //
    Status = gBS->CloseProtocol (
                    gSampleDrvDevice->SerialIoDeviceHandle,
                    &gEfiDebugSerialIoProtocolGuid,
                    This->DriverBindingHandle,
                    gSampleDrvDevice->SampleDrvDeviceHandle
                    );

    if (EFI_ERROR (Status)) {
      return Status;
    }
    //
    // Unpublish our protocols (DevicePath, SampleDrv)
    //
    Status = gBS->UninstallMultipleProtocolInterfaces (
                    gSampleDrvDevice->SampleDrvDeviceHandle,
                    &gEfiDevicePathProtocolGuid,
                    gSampleDrvDevice->SampleDrvDevicePath,
                    &gEfiSampleDrvProtocolGuid,
                    &gSampleDrvDevice->SampleDrvInterface,
                    NULL
                    );

    if (EFI_ERROR (Status)) {
      gBS->OpenProtocol (
            ControllerHandle,
            &gEfiDebugSerialIoProtocolGuid,
            &gSampleDrvDevice->SerialIoBinding,
            This->DriverBindingHandle,
            gSampleDrvDevice->SampleDrvDeviceHandle,
            EFI_OPEN_PROTOCOL_BY_CHILD_CONTROLLER
            );
    } else {
      gSampleDrvDevice->SampleDrvDeviceHandle = NULL;
    }
  }

  return Status;
}
//
// SAMPLEDRV protocol member functions
//
EFI_STATUS
EFIAPI
SampleDrvReset (
  IN EFI_SAMPLEDRV_PROTOCOL   *This
  )
/*++

Routine Description:
  SampleDrv protocol member function.  Calls SerialIo:GetControl to flush buffer.
  We cannot call SerialIo:SetAttributes because it uses pool services, which use
  locks, which affect TPL, so it's not interrupt context safe or re-entrant.
  SerialIo:Reset() calls SetAttributes, so it can't be used either.
  
  The port itself should be fine since it was set up during initialization.  
  
Arguments:
  This

Returns:

  EFI_SUCCESS

--*/
{
  SAMPLEDRV_DEVICE  *SampleDrvDevice;
  UINTN             BufferSize;
  UINTN             BitBucket;

  SampleDrvDevice = SAMPLEDRV_DEVICE_FROM_THIS (This);
  while (This->Poll (This) == EFI_SUCCESS) {
    BufferSize = 1;
    This->Read (This, 0, &BufferSize, &BitBucket);
  }

  return EFI_SUCCESS;
}

EFI_STATUS
EFIAPI
SampleDrvRead (
  IN EFI_SAMPLEDRV_PROTOCOL   *This,
  IN UINT32                   Timeout,
  IN OUT UINTN                *BufferSize,
  IN VOID                     *Buffer
  )
/*++

Routine Description:
  SampleDrv protocol member function.  Calls SerialIo:Read() after setting
  if it's different than the last SerialIo access.
  
Arguments:
  IN EFI_SAMPLEDRV_PROTOCOL   *This
  IN UINT32                   Timeout,
  IN OUT UINTN                *BufferSize,
  IN VOID                     *Buffer

Returns:

  EFI_STATUS

--*/
{
  SAMPLEDRV_DEVICE  *SampleDrvDevice;
  UINTN             LocalBufferSize;
  EFI_STATUS        Status;
  UINT8             *BufferPtr;

  SampleDrvDevice = SAMPLEDRV_DEVICE_FROM_THIS (This);
  BufferPtr       = Buffer;
  LocalBufferSize = *BufferSize;
  do {
    Status = SampleDrvDevice->SerialIoBinding->Read (
                                                SampleDrvDevice->SerialIoBinding,
                                                &LocalBufferSize,
                                                BufferPtr
                                                );
    if (Status == EFI_TIMEOUT) {
      if (Timeout > SAMPLEDRV_UART_DEFAULT_TIMEOUT) {
        Timeout -= SAMPLEDRV_UART_DEFAULT_TIMEOUT;
      } else {
        Timeout = 0;
      }
    } else if (EFI_ERROR (Status)) {
      break;
    }

    BufferPtr += LocalBufferSize;
    LocalBufferSize = *BufferSize - (BufferPtr - (UINT8 *) Buffer);
  } while (LocalBufferSize != 0 && Timeout > 0);

  *BufferSize = (UINTN) (BufferPtr - (UINT8 *) Buffer);

  return Status;
}

EFI_STATUS
EFIAPI
SampleDrvWrite (
  IN EFI_SAMPLEDRV_PROTOCOL   *This,
  IN UINT32                   Timeout,
  IN OUT UINTN                *BufferSize,
  OUT VOID                    *Buffer
  )
/*++

Routine Description:
  SampleDrv protocol member function.  Calls SerialIo:Write() Writes 8 bytes at
  a time and does a GetControl between 8 byte writes to help insure reads are
  interspersed This is poor-man's flow control..
  
Arguments:
  This               - Pointer to SampleDrv protocol
  Timeout            - Timeout value
  BufferSize         - On input, the size of Buffer. 
                       On output, the amount of data actually written.
  Buffer             - Pointer to buffer to write

Returns:
  EFI_SUCCESS        - The data was written.
  EFI_DEVICE_ERROR   - The device reported an error.
  EFI_TIMEOUT        - The data write was stopped due to a timeout.

--*/
{
  SAMPLEDRV_DEVICE  *SampleDrvDevice;
  UINTN             Position;
  UINTN             WriteSize;
  EFI_STATUS        Status;
  UINT32            SerialControl;

  Status          = EFI_SUCCESS;
  SampleDrvDevice = SAMPLEDRV_DEVICE_FROM_THIS (This);

  WriteSize       = 8;
  for (Position = 0; Position < *BufferSize && !EFI_ERROR (Status); Position += WriteSize) {
    SampleDrvDevice->SerialIoBinding->GetControl (
                                        SampleDrvDevice->SerialIoBinding,
                                        &SerialControl
                                        );
    if (*BufferSize - Position < 8) {
      WriteSize = *BufferSize - Position;
    }

    Status = SampleDrvDevice->SerialIoBinding->Write (
                                                SampleDrvDevice->SerialIoBinding,
                                                &WriteSize,
                                                &((UINT8 *) Buffer)[Position]
                                                );
  }

  *BufferSize = Position;
  return Status;
}

EFI_STATUS
EFIAPI
SampleDrvPoll (
  IN EFI_SAMPLEDRV_PROTOCOL   *This
  )
/*++

Routine Description:
  SampleDrv protocol member function.  Calls SerialIo:Write() after setting
  if it's different than the last SerialIo access.
  
Arguments:
  IN EFI_SAMPLEDRV_PROTOCOL   *This

Returns:
  EFI_SUCCESS - At least 1 character is ready to be read from the SampleDrv interface
  EFI_NOT_READY - There are no characters ready to read from the SampleDrv interface
  EFI_DEVICE_ERROR - A hardware failure occured... (from SerialIo)

--*/
{
  EFI_STATUS        Status;
  UINT32            SerialControl;
  SAMPLEDRV_DEVICE  *SampleDrvDevice;

  SampleDrvDevice = SAMPLEDRV_DEVICE_FROM_THIS (This);

  Status = SampleDrvDevice->SerialIoBinding->GetControl (
                                              SampleDrvDevice->SerialIoBinding,
                                              &SerialControl
                                              );

  if (!EFI_ERROR (Status)) {
    if (SerialControl & EFI_SERIAL_INPUT_BUFFER_EMPTY) {
      Status = EFI_NOT_READY;
    } else {
      Status = EFI_SUCCESS;
    }
  }

  return Status;
}
//
// Misc. functions local to this module..
//
STATIC
VOID
GetSampleDrvVariable (
  SAMPLEDRV_DEVICE            *SampleDrvDevice
  )
/*++

Routine Description:
  Local worker function to obtain device path information from SampleDrv variable.
  Records requested settings in SampleDrv device structure.
  
Arguments:
  SAMPLEDRV_DEVICE  *SampleDrvDevice,

Returns:

  Nothing

--*/
{
  UINTN                     DataSize;
  EFI_DEVICE_PATH_PROTOCOL  *DevicePath;
  EFI_STATUS                Status;

  DataSize = 0;

  Status = gRT->GetVariable (
                  EFI_SAMPLEDRV_VARIABLE_NAME,
                  &gEfiSampleDrvVariableGuid,
                  NULL,
                  &DataSize,
                  SampleDrvDevice->SampleDrvVariable
                  );

  if (Status == EFI_BUFFER_TOO_SMALL) {
    if (gSampleDrvDevice->SampleDrvVariable != NULL) {
      gBS->FreePool (gSampleDrvDevice->SampleDrvVariable);
    }

    SampleDrvDevice->SampleDrvVariable = EfiLibAllocatePool (DataSize);
    if (SampleDrvDevice->SampleDrvVariable != NULL) {
      gRT->GetVariable (
            EFI_SAMPLEDRV_VARIABLE_NAME,
            &gEfiSampleDrvVariableGuid,
            NULL,
            &DataSize,
            SampleDrvDevice->SampleDrvVariable
            );
      DevicePath = (EFI_DEVICE_PATH_PROTOCOL *) SampleDrvDevice->SampleDrvVariable;
      while (!EfiIsDevicePathEnd (DevicePath) && !EfiIsUartDevicePath (DevicePath)) {
        DevicePath = EfiNextDevicePathNode (DevicePath);
      }

      if (EfiIsDevicePathEnd (DevicePath)) {
        gBS->FreePool (gSampleDrvDevice->SampleDrvVariable);
        SampleDrvDevice->SampleDrvVariable = NULL;
      } else {
        gBS->CopyMem (
              &SampleDrvDevice->BaudRate,
              &((UART_DEVICE_PATH *) DevicePath)->BaudRate,
              sizeof (((UART_DEVICE_PATH *) DevicePath)->BaudRate)
              );
        SampleDrvDevice->ReceiveFifoDepth = SAMPLEDRV_UART_DEFAULT_FIFO_DEPTH;
        SampleDrvDevice->Timeout          = SAMPLEDRV_UART_DEFAULT_TIMEOUT;
        gBS->CopyMem (
              &SampleDrvDevice->Parity,
              &((UART_DEVICE_PATH *) DevicePath)->Parity,
              sizeof (((UART_DEVICE_PATH *) DevicePath)->Parity)
              );
        gBS->CopyMem (
              &SampleDrvDevice->DataBits,
              &((UART_DEVICE_PATH *) DevicePath)->DataBits,
              sizeof (((UART_DEVICE_PATH *) DevicePath)->DataBits)
              );
        gBS->CopyMem (
              &SampleDrvDevice->StopBits,
              &((UART_DEVICE_PATH *) DevicePath)->StopBits,
              sizeof (((UART_DEVICE_PATH *) DevicePath)->StopBits)
              );
      }
    }
  }
}

STATIC
EFI_STATUS
EFIAPI
ImageUnloadHandler (
  EFI_HANDLE ImageHandle
  )
/*++

Routine Description:
  Unload function that is registered in the LoadImage protocol.  It un-installs
  protocols produced and deallocates pool used by the driver.  Called by the core
  when unloading the driver.
  
Arguments:
  EFI_HANDLE ImageHandle

Returns:

  EFI_SUCCESS

--*/
{
  EFI_STATUS  Status;

  if (gSampleDrvDevice->SerialIoBinding != NULL) {
    return EFI_ABORTED;
  }

#if (EFI_SPECIFICATION_VERSION >= 0x00020000)
  Status = gBS->UninstallMultipleProtocolInterfaces (
                  ImageHandle,
                  &gEfiDriverBindingProtocolGuid,
                  &gSampleDrvDevice->DriverBindingInterface,
                  &gEfiComponentName2ProtocolGuid,
                  &gSampleDrvDevice->ComponentNameInterface,
                  NULL
                  );
#else
  Status = gBS->UninstallMultipleProtocolInterfaces (
                  ImageHandle,
                  &gEfiDriverBindingProtocolGuid,
                  &gSampleDrvDevice->DriverBindingInterface,
                  &gEfiComponentNameProtocolGuid,
                  &gSampleDrvDevice->ComponentNameInterface,
                  NULL
                  );
#endif
  if (EFI_ERROR (Status)) {
    return Status;
  }
  //
  // Clean up allocations
  //
  if (gSampleDrvDevice->SampleDrvVariable != NULL) {
    gBS->FreePool (gSampleDrvDevice->SampleDrvVariable);
  }

  gBS->FreePool (gSampleDrvDevice);

  return EFI_SUCCESS;
}
