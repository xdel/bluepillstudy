/*++

Copyright (c) 2004 - 2007, Intel Corporation                                                         
All rights reserved. This program and the accompanying materials                          
are licensed and made available under the terms and conditions of the BSD License         
which accompanies this distribution.  The full text of the license may be found at        
http://opensource.org/licenses/bsd-license.php                                            
                                                                                          
THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,                     
WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.             

Module Name:
  SampleDrv.h

Abstract:
  Definitions and prototypes for SampleDrv driver

--*/

#ifndef __SAMPLEDRV_H__
#define __SAMPLEDRV_H__

//
// common EFI header files
//
#include "Tiano.h"

//
// library header files
//
#include "EfiDriverLib.h"

//
// consumed protocols
//
#include EFI_PROTOCOL_DEFINITION (LoadedImage)
#include EFI_PROTOCOL_DEFINITION (DebugSerialIo)
#include EFI_PROTOCOL_DEFINITION (DevicePath)

//
// produced protocols
//
#include EFI_PROTOCOL_DEFINITION (DriverBinding)
#include EFI_PROTOCOL_DEFINITION (ComponentName)
#include EFI_PROTOCOL_DEFINITION (ComponentName2)
#include EFI_PROTOCOL_DEFINITION (SampleDrv)

//
// local type definitions
//
#define SAMPLEDRV_DEVICE_SIGNATURE  EFI_SIGNATURE_32 ('S', 'M', 'P', 'D')

//
// Device structure used by driver
//
typedef struct {
  UINT32                      Signature;
  EFI_HANDLE                  DriverBindingHandle;
  EFI_HANDLE                  SampleDrvDeviceHandle;
  VOID                        *SampleDrvVariable;

  EFI_DRIVER_BINDING_PROTOCOL DriverBindingInterface;
#if (EFI_SPECIFICATION_VERSION >= 0x00020000)
  EFI_COMPONENT_NAME2_PROTOCOL ComponentNameInterface;
#else
  EFI_COMPONENT_NAME_PROTOCOL ComponentNameInterface;
#endif
  EFI_DEVICE_PATH_PROTOCOL    *SampleDrvDevicePath;
  EFI_SAMPLEDRV_PROTOCOL       SampleDrvInterface;

  EFI_HANDLE                  SerialIoDeviceHandle;
  EFI_SERIAL_IO_PROTOCOL      *SerialIoBinding;
  UINT64                      BaudRate;
  UINT32                      ReceiveFifoDepth;
  UINT32                      Timeout;
  EFI_PARITY_TYPE             Parity;
  UINT8                       DataBits;
  EFI_STOP_BITS_TYPE          StopBits;
} SAMPLEDRV_DEVICE;

#define SAMPLEDRV_DEVICE_FROM_THIS(a)     CR (a, SAMPLEDRV_DEVICE, SampleDrvInterface, SAMPLEDRV_DEVICE_SIGNATURE)

#define EFI_ACPI_PC_COMPORT_HID           EISA_PNP_ID (0x0500)
#define EFI_ACPI_16550UART_HID            EISA_PNP_ID (0x0501)

#define SAMPLEDRV_UART_DEFAULT_BAUDRATE   115200
#define SAMPLEDRV_UART_DEFAULT_PARITY     0
#define SAMPLEDRV_UART_DEFAULT_FIFO_DEPTH 16
#define SAMPLEDRV_UART_DEFAULT_TIMEOUT    50000 // 5 ms
#define SAMPLEDRV_UART_DEFAULT_DATA_BITS  8
#define SAMPLEDRV_UART_DEFAULT_STOP_BITS  1

#define SAMPLEDRV_DRIVER_VERSION          1

#define EfiIsUartDevicePath(dp)           (DevicePathType (dp) == MESSAGING_DEVICE_PATH && DevicePathSubType (dp) == MSG_UART_DP)

//
// globals
//
extern SAMPLEDRV_DEVICE *gSampleDrvDevice;

//
// Driver binding interface functions...
//
EFI_STATUS
SampleDrvEntryPoint (
  IN EFI_HANDLE                     ImageHandle,
  IN EFI_SYSTEM_TABLE               *SystemTable
  )
;

EFI_STATUS
EFIAPI
SampleDrvSupported (
  IN EFI_DRIVER_BINDING_PROTOCOL    *This,
  IN EFI_HANDLE                     Controller,
  IN EFI_DEVICE_PATH_PROTOCOL       *RemainingDevicePath
  )
;

EFI_STATUS
EFIAPI
SampleDrvStart (
  IN EFI_DRIVER_BINDING_PROTOCOL    *This,
  IN EFI_HANDLE                     Controller,
  IN EFI_DEVICE_PATH_PROTOCOL       *RemainingDevicePath
  )
;

EFI_STATUS
EFIAPI
SampleDrvStop (
  IN  EFI_DRIVER_BINDING_PROTOCOL    *This,
  IN  EFI_HANDLE                     Controller,
  IN  UINTN                          NumberOfChildren,
  IN  EFI_HANDLE                     *ChildHandleBuffer
  )
;

//
// EFI Component Name Functions
//
EFI_STATUS
EFIAPI
SampleDrvComponentNameGetDriverName (
#if (EFI_SPECIFICATION_VERSION >= 0x00020000)
  IN  EFI_COMPONENT_NAME2_PROTOCOL  *This,
#else
  IN  EFI_COMPONENT_NAME_PROTOCOL   *This,
#endif
  IN  CHAR8                         *Language,
  OUT CHAR16                        **DriverName
  )
;

EFI_STATUS
EFIAPI
SampleDrvComponentNameGetControllerName (
#if (EFI_SPECIFICATION_VERSION >= 0x00020000)
  IN  EFI_COMPONENT_NAME2_PROTOCOL                     *This,
#else
  IN  EFI_COMPONENT_NAME_PROTOCOL                      *This,
#endif
  IN  EFI_HANDLE                                       ControllerHandle,
  IN  EFI_HANDLE                                       ChildHandle        OPTIONAL,
  IN  CHAR8                                            *Language,
  OUT CHAR16                                           **ControllerName
  )
;

//
// SampleDrv member functions
//
EFI_STATUS
EFIAPI
SampleDrvReset (
  IN EFI_SAMPLEDRV_PROTOCOL         *This
  )
;

EFI_STATUS
EFIAPI
SampleDrvRead (
  IN EFI_SAMPLEDRV_PROTOCOL         *This,
  IN UINT32                         Timeout,
  IN OUT UINTN                      *BufferSize,
  IN VOID                           *Buffer
  )
;

EFI_STATUS
EFIAPI
SampleDrvWrite (
  IN EFI_SAMPLEDRV_PROTOCOL         *This,
  IN UINT32                         Timeout,
  IN OUT UINTN                      *BufferSize,
  OUT VOID                          *Buffer
  )
;

EFI_STATUS
EFIAPI
SampleDrvPoll (
  IN EFI_SAMPLEDRV_PROTOCOL         *This
  )
;

#endif
