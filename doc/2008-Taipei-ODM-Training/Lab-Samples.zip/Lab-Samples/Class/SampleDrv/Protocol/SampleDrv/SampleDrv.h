/*++

Copyright (c)  1999 - 2002 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.

Module Name:

    SampleDrv.h

Abstract:

--*/


#ifndef _SAMPLE_DRV_H_
#define _SAMPLE_DRV_H_

#include "EfiApi.h"

//
// SampleDrvIo protocol {EBA4E8D2-3858-41EC-A281-2647BA9660D0}
//
#define EFI_SAMPLEDRV_PROTOCOL_GUID \
  { 0xEBA4E8D2, 0x3858, 0x41EC, 0xA2, 0x81, 0x26, 0x47, 0xBA, 0x96, 0x60, 0xD0 }

extern EFI_GUID  gEfiSampleDrvProtocolGuid;

EFI_FORWARD_DECLARATION (EFI_SAMPLEDRV_PROTOCOL);

//
// SampleDrv member functions
//
typedef
EFI_STATUS
(EFIAPI *EFI_SAMPLEDRV_RESET) (
  IN EFI_SAMPLEDRV_PROTOCOL               *This
  );

typedef
EFI_STATUS
(EFIAPI *EFI_SAMPLEDRV_WRITE) (
  IN EFI_SAMPLEDRV_PROTOCOL               *This,
  IN UINT32                               Timeout,
  IN OUT UINTN                            *BufferSize,
  IN VOID                                 *Buffer
  );

typedef
EFI_STATUS
(EFIAPI *EFI_SAMPLEDRV_READ) (
  IN EFI_SAMPLEDRV_PROTOCOL               *This,
  IN UINT32                               Timeout,
  IN OUT UINTN                            *BufferSize,
  OUT VOID                                *Buffer
  );

typedef
EFI_STATUS
(EFIAPI *EFI_SAMPLEDRV_POLL) (
  IN EFI_SAMPLEDRV_PROTOCOL               *This
  );
  
//
// SampleDrv protocol definition
//
typedef struct _EFI_SAMPLEDRV_PROTOCOL {
  EFI_SAMPLEDRV_RESET                     Reset;
  EFI_SAMPLEDRV_WRITE                     Write;
  EFI_SAMPLEDRV_READ                      Read;
  EFI_SAMPLEDRV_POLL                      Poll;
} EFI_SAMPLEDRV_PROTOCOL;

//
// SAMPLEDRV variable definitions...
//
#define EFI_SAMPLEDRV_VARIABLE_NAME L"SAMPLEDRV"
#define EFI_SAMPLEDRV_VARIABLE_GUID EFI_SAMPLEDRV_PROTOCOL_GUID
#define gEfiSampleDrvVariableGuid gEfiSampleDrvProtocolGuid

//
// SampleDrv device path definitions...
//

#define DEVICE_PATH_MESSAGING_SAMPLEDRV EFI_SAMPLEDRV_PROTOCOL_GUID
#define gEfiSampleDrvDevicePathGuid gEfiSampleDrvProtocolGuid

typedef struct {
  EFI_DEVICE_PATH_PROTOCOL                Header;
  EFI_GUID                                Guid;
} SAMPLEDRV_DEVICE_PATH;

#endif /* _SAMPLE_DRV_H_ */

