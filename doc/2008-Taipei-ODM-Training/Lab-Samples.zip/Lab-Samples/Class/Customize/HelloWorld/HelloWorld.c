#include "Tiano.h"
#include "EfiShellLib.h"
#include "HelloWorld.h"

extern UINT8 STRING_ARRAY_NAME[];


//
// This is the generated header file which includes whatever needs to be exported (strings + IFR)
//
#include STRING_DEFINES_FILE
//#include ".\IA32\HelloWorldStrDefs.h"

//
// Global Variables
//
EFI_HII_HANDLE  HiiHandle;
EFI_GUID        EfiHelloWorldGuid = EFI_HELLOWORLD_GUID;

EFI_BOOTSHELL_CODE(
  EFI_DRIVER_ENTRY_POINT (HelloWorldAppEntry)
)
//
// Entry point of HelloWorld application
//
EFI_STATUS
HelloWorldAppEntry (
  IN EFI_HANDLE         ImageHandle,
  IN EFI_SYSTEM_TABLE   *SystemTable
  )
/*++
Standard Routine description is omitted here
--*/
{
  EFI_STATUS        Status;
  EFI_SHELL_APP_INIT (ImageHandle, SystemTable);
 
  Status =  EFI_SUCCESS;
  //
  // We are no being installed as an internal command driver, initialize
  // as an nshell app and run
  //
  InitializeShellLib (ImageHandle, SystemTable);
  EFI_NO_BOOTSHELL_CODE (
    EFI_SHELL_APP_INIT (ImageHandle, SystemTable);
  )
  //
  //
  // Register our string package with HII and return the handle to it.
  // If previously registered we will simply receive the handle
  //
  EFI_SHELL_STR_INIT (HiiHandle, STRING_ARRAY_NAME, EfiHelloWorldGuid);
 

  //
  // Display the string!
  //
  PrintToken (STRING_TOKEN(STR_HELLOWORLD), HiiHandle);
  WaitForSingleEvent(ST->ConIn->WaitForKey,0);
  return EFI_SUCCESS;
}
