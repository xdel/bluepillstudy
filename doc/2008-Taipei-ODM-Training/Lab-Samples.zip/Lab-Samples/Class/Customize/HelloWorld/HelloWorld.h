//
// This file contains a 'EFI Shell Code' and is licensed as    
// such under the terms of your license agreement with Intel or
// your vendor.  This file may be modified by the user, subject
// to the additional terms of the license agreement.           
//
/*++

Copyright (c)  1999 - 2002 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.


Module Name:

  HelloWorld.h

Abstract:

  declares interface functions

Revision History

--*/

#ifndef _EFI_SHELL_HelloWorld_
#define _EFI_SHELL_HelloWorld_

#define EFI_HELLOWORLD_GUID \
  { \
   0xf2a304e6, 0x302a, 0x4f44, 0x8f, 0x5, 0xf8, 0xff, 0xf3, 0x49, 0xd7, 0xcd\
  }

#endif
