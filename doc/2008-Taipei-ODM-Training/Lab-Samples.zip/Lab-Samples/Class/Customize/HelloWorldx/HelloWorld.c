/*++

Copyright (c)  1999 - 2006 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.


Module Name:
  HelloWorld.c

Abstract:

--*/

#include "Tiano.h"
#include "EfiDriverLib.h"
#include "EfiPrintLib.h"
#include EFI_PROTOCOL_DEFINITION (ConsoleControl)

EFI_APPLICATION_ENTRY_POINT(HelloMain)

/*++

Routine Description:
  Initialize the PEI emulation shell command

Arguments:
  (Standard EFI Image entry - EFI_IMAGE_ENTRY_POINT)

Returns:

--*/
EFI_STATUS
HelloMain (
  IN EFI_HANDLE                            ImageHandle,
  IN EFI_SYSTEM_TABLE                      *SystemTable
  )
/*++

Routine Description:
  
  Hello world!

Arguments:

  ImageHandle  - The image handle
  SystemTable  - The system table

Returns:
  
--*/

{
  EFI_CONSOLE_CONTROL_PROTOCOL  *Console;
  EFI_STATUS                    Status;
  UINTN                         Index;
  UINTN							i;
  EFI_GRAPHICS_OUTPUT_BLT_PIXEL ForeGround;
  EFI_GRAPHICS_OUTPUT_BLT_PIXEL BackGround;

  EfiInitializeDriverLib (ImageHandle, SystemTable);

  Status = gBS->LocateProtocol (
                  &gEfiConsoleControlProtocolGuid,
                  NULL,
                  &Console
                  );

  if (EFI_ERROR (Status)) {
    return Status;
  }

  Console->SetMode (Console, EfiConsoleControlScreenGraphics);
  // Clear the previous display on the console by printing Spaces on black background
  for(i=0; i<600 ;i=i+16)
  {
	                           //---------- ---------- ---------- ---------- ---------- --------- ----------- ----------
	PrintXY (0, i, NULL, NULL, L"                                                                                       \n");

  } 
// print out Grey
  PrintXY (0, 0, NULL, NULL, L"Hello World!\n");
  PrintXY (10, 20, NULL, NULL, L"Hello World!\n");

  //print out grey with Black background
  ForeGround.Blue   = 150;
  ForeGround.Red    = 150;
  ForeGround.Green  = 150;
  BackGround.Blue   = 0;
  BackGround.Red    = 0;
  BackGround.Green  = 0;
  PrintXY (50, 50, &ForeGround, &BackGround, L"Hello World!\n");
  PrintXY (60, 70, &ForeGround, &BackGround, L"Hello World!\n");

  //Print out Blue
  ForeGround.Blue   = 250;
  ForeGround.Red    = 0;
  ForeGround.Green  = 0;
  BackGround.Blue   = 0;
  BackGround.Red    = 0;
  BackGround.Green  = 0;
  PrintXY (100, 100, &ForeGround, &BackGround, L"Hello World!\n");
  PrintXY (110, 120, &ForeGround, &BackGround, L"Hello World!\n");

  //Print out Red
  ForeGround.Blue   = 0;
  ForeGround.Red    = 250;
  ForeGround.Green  = 0;
  BackGround.Blue   = 0;
  BackGround.Red    = 0;
  BackGround.Green  = 0;
  PrintXY (150, 150, &ForeGround, &BackGround, L"Hello World!\n");
  PrintXY (160, 170, &ForeGround, &BackGround, L"Hello World!\n");

  //Print out Green
  ForeGround.Blue   = 0;
  ForeGround.Red    = 0;
  ForeGround.Green  = 250;
  BackGround.Blue   = 0;
  BackGround.Red    = 0;
  BackGround.Green  = 0;
  PrintXY (200, 200, &ForeGround, &BackGround, L"Hello World!\n");
  PrintXY (210, 220, &ForeGround, &BackGround, L"Hello World!\n");

  PrintXY (240, 260, &ForeGround, &BackGround, L"Prese any Key to continue\n");
  gBS->WaitForEvent (1, &gST->ConIn->WaitForKey, &Index);
  Console->SetMode (Console, EfiConsoleControlScreenText);

  return EFI_SUCCESS;
}
