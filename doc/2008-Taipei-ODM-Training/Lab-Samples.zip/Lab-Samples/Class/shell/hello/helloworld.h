//
// HelloWorld.h
//
#ifndef _EFI_HELLOWORLD_H
#define _EFI_HELLOWORLD_H

#define HELLOWORLD_STRING_PACK_GUID \
		{\
			0x6435f523, 0x5cd3, 0x444f, 0xa4, 0x23, 0x83, 0x4f, 0xbb, 0x71, 0x29, 0xc7\
		}

#endif

